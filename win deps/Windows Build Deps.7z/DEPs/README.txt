This archive contains the dependency files required by MinGW/MSYS when building Qtpfsgui in Windows.
More info can be found at [1].

The archive contains:
- the fftw3f dll+header files
  v3.2 copied from the [2] file linked from [3]
- the libexiv2 static+dynamic libs+headers
  v0.18 compiled in mingw+msys, see [4] and [1]
- the OpenEXR static+dynamic libs+headers
  IlmBase 1.0.1 and OpenEXR 1.6.1 from [5]
- the libtiff dll+headers
  v3.8.2 from [6]
- the win32 pthreads dll (GC2 variant)
  v2.8.0 from [7]

The archive has to be extracted to a directory named ../DEPs relative to the Qtpfsgui sources.
If you also need to build yourself the dependencies you may the zlib library, it can be found here: [8]

References:
[1] http://qtpfsgui.wiki.sourceforge.net/Compiling+on+Windows
[2] ftp://ftp.fftw.org/pub/fftw/fftw-3.2-dll.zip
[3] http://www.fftw.org/install/windows.html
[4] http://uk.groups.yahoo.com/group/exiv2/message/1484
[5] http://www.openexr.com/downloads.html
[6] http://gnuwin32.sourceforge.net/packages/tiff.htm
[7] http://sourceware.org/pthreads-win32/
[8] http://gnuwin32.sourceforge.net/packages/zlib.htm

--
Giuseppe Rota
grota at users.sourceforge.net
