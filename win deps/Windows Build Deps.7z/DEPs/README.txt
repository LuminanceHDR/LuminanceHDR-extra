This zip file contains the dependency files required by MinGW/MSYS when building Qtpfsgui in Windows.
Another requirement is the libtiff GnuWin32 package (http://gnuwin32.sourceforge.net/packages/tiff.htm)

The archive contains
- the fftw3f dll+header files
- the libexiv2 static libs+headers
- the OpenEXR static libs+headers

The zip archive has to be extracted to a directory named ../DEPs relative to the Qtpfsgui sources.

--
Giuseppe Rota
grota at users.sourceforge.net
